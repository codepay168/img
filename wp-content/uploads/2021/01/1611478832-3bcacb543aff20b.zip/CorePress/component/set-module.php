<h3>代码高亮模块</h3>
<div class="set-plane">
    <div class="set-title">
        功能开关
    </div>
    <div class="set-object">
        <el-switch
                v-model="set.module.highlight"
                :active-value="1"
                :inactive-value="0"
        >
        </el-switch>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        高亮风格
    </div>
    <div class="set-object">
        <el-switch
                v-model="set.module.highlighttheme"
                :active-value="1"
                :inactive-value="0"
                active-text="暗色风格"
                inactive-text="亮色风格"
        >
        </el-switch>
    </div>
</div>
<h3>图片设置</h3>
<div class="set-plane">
    <div class="set-title">
        图片延迟加载
    </div>
    <div class="set-object">
        <el-switch
                v-model="set.module.imglazyload"
                :active-value="1"
                :inactive-value="0"
        >
        </el-switch>
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
    </div>
    <div class="set-object">
        图片延迟加载，可提高网页加载速度
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
        图片灯箱
    </div>
    <div class="set-object">
        <el-switch
                v-model="set.module.imglightbox"
                :active-value="1"
                :inactive-value="0"
        >
        </el-switch>
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
    </div>
    <div class="set-object">
        点击图片直接当前页面打开
    </div>
</div>
<h3>SMTP 邮件服务器</h3>
<div class="set-plane">
    <div class="set-title">
        功能开关
    </div>
    <div class="set-object">
        <el-switch
                v-model="set.module.smtp"
                :active-value="1"
                :inactive-value="0"
        >
        </el-switch>
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
        发件人邮箱
    </div>
    <div class="set-object">
        <el-input placeholder="" v-model="set.module.smtpuser" size="small">
        </el-input>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        发件人密码
    </div>
    <div class="set-object">
        <el-input placeholder="" v-model="set.module.smtppwd" size="small">
        </el-input>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        SMTP 邮件服务器地址
    </div>
    <div class="set-object">
        <el-input placeholder="" v-model="set.module.smtphost" size="small">
        </el-input>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        SMTP端口
    </div>
    <div class="set-object">
        <el-input placeholder="" v-model="set.module.smtpport" size="small">
        </el-input>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        发件人昵称
    </div>
    <div class="set-object">
        <el-input placeholder="" v-model="set.module.smtpname" size="small">
        </el-input>
    </div>
</div>
<div class="set-plane">
    <div class="set-title">
        SMTP加密方式
    </div>
    <div class="set-object">
        <el-radio v-model="set.module.smtpencrypttype" label="no">不加密</el-radio>
        <el-radio v-model="set.module.smtpencrypttype" label="ssl">SSL/TLS</el-radio>
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
    </div>
    <div class="set-object">
        <el-input placeholder="收件邮箱地址" v-model="set.module.testmail" size="small">
        </el-input>
        <br>
    </div>
</div>

<div class="set-plane">
    <div class="set-title">
    </div>
    <div class="set-object">
        <el-button slot="append" type="primary" size="small" @click="mailtest">发信测试</el-button>
    </div>
</div>